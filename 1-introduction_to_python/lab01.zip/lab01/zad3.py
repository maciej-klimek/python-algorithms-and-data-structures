import time

tbl = [1,2,3,4,5]


start1 = time.time()
for i in tbl:
    print(i)
end1 = time.time()

start2 = time.time()
for i in range(len(tbl)):
    print(i)
end2= time.time()

print(end1-start1, "vs", end2-start2)