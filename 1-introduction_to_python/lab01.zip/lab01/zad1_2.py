import statistics


def create(tbl):
    i = 0
    while len(tbl) < 48:
        x =  (tbl[i] + tbl[i+1])/(tbl[i+1] - tbl[i])
        tbl.append(x)
        i+=1
    return tbl

def check(tbl):
    indxTbl = []
    for i in range(48):
        indxTbl.append(0)
    
    for i in range(len(tbl)-1):
        for j in range(len(tbl)-1):
            if tbl[i] == tbl[j]:
                indxTbl[i]+=1

    sum = 0
    for i in tbl:
        sum+=i

    print(f"Średnia = {sum/48}")

    moda = indxTbl.index(max(indxTbl))
    if tbl[moda] == 1:
        print("Brak mody w tablicy, każda wartość pojawia się dokładnie jeden raz")
    else:
        print(f"Moda = {tbl[moda]}")

def main():
    L = create([1, 2])
    check(L)


main()




