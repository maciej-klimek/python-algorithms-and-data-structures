
mainTbl = [
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 0]
           ]

def printTbl(tbl):
    c = 1
    print("\n----------------------------------")
    print("     a   b   c")
    for i in tbl:
        print("   -------------")
        print(f"{c}  |", end = '')
        c+=1
        for j in i:
            if j == 1:
                j = "x"
            elif j == 2:
                j = "o"
            else:
                j = " "

            print(f" {j} |", end ='')
        print()
    print("   -------------")


def checkWin(tbl):
    for line in tbl:
        if line[0] == line[1] == line[2] != 0:
            return line[0]

    for line in range(3):
        if tbl[0][line] == tbl[1][line] == tbl[2][line] != 0:
            return tbl[0][line]

    if tbl[0][0] == tbl[1][1] == tbl[2][2] != 0:
        return tbl[0][0]

    if tbl[0][2] == tbl[1][1] == tbl[2][0] != 0:
        return tbl[0][2]
    
    draw = True
    for line in tbl:
        for field in line:
            if field == 0:
                draw = False

    if draw == False:
        return 0 
    return 3
    

def makeMove(tbl, player):
    valid = False
    while not valid:
        x, y = 3, 3
        if player == 1:
            playerDisplay = 'x'
        else:
            playerDisplay = 'o'

        print(f"Wybierz ruch dla {playerDisplay} \n-> ", end = '')
        move = str(input())
        if len(move) != 2:
            print("Niepoprawny ruch")
        else:
        
            if move[0] == "a":
                y = 0
            elif move[0] == "b":
                y = 1
            elif move[0] == "c":
                y = 2
            

            if move[1] == "1":
                x = 0
            elif move[1] == "2":
                x = 1
            elif move[1] == "3":
                x = 2
            
            if x != 3 and y != 3 and tbl[x][y] == 0:
                valid = True
                tbl[x][y] = player
            else:
                print("Niepoprawny ruch")


def main():
    
    result = 0
    player = [1,2]
    while result == 0:
        printTbl(mainTbl)
        makeMove(mainTbl, player[0])
        result = checkWin(mainTbl)
        player[0], player[1] = player[1], player[0]


    printTbl(mainTbl)
    if result == 1:
        print("Wygrał gracz x")
    elif result == 2:
        print("Wygrał gracz o")
    else:
        print("Remis")


main()
